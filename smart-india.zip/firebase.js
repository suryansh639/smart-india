const firebaseConfig = {
	apiKey: "AIzaSyAbLPg52L-GuIzQqhVPO3JZXfKTi85lytM",
	authDomain: "myportfolio-f9d82.firebaseapp.com",
	projectId: "myportfolio-f9d82",
	storageBucket: "myportfolio-f9d82.appspot.com",
	messagingSenderId: "359255569473",
	appId: "1:359255569473:web:59cb3c1b340fc3587382c0",
	measurementId: "G-MTMDYMZ7HD"
  };
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();

